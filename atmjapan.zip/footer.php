<footer>
<link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css">
<nav class="navbar navbar-inverse " style="margin-bottom:0px; border-radius:0px" >
<div class="row page-header" id="contactus">
<div class="col-sm-1">
</div>
<div class="col-sm-2"> 
<h4>Route Map</h4>
<div style="width:300px;max-width:100%;list-style:none; transition: none;overflow:hidden;">
<div id="gmap-canvas" style="height:100%; width:100%;max-width:100%;">
<iframe style="height:53%;width:100%;border:0;" frameborder="0" src="https://maps.google.com/maps?hl=en&q=4-20-5 Shiritori Katsushika KU  Tokyo Japan&ie=UTF8&t=roadmap&z=10&iwloc=B&output=embed">
</iframe>
</div>
<a class="google-maps-code" href="https://www.bootstrapskins.com/themes/online-casino" id="enable-map-data">
</a>
</div>
</div>
<div class="col-sm-2"> 
<h4> Address </h4>
<address> 
ATM MARKETING CO LTD.<br>
4-20-5 Shiritori Katsushika KU <br>
Tokyo, Japan<br>

</address>
</div>
<div class="col-sm-2"> 
<h4>Site Map </h4>

 

<a href="index.php">Home </a> <br>


</div>
<div class="col-sm-2"> 
<h4>Contact Us</h4>

<p>
PHONE: 0081-3-3603-2617 <br>
  
  </p>
   <p>
FAX: 0081-3-3603-2618
</p>
<p>

</p>
<p>

</p>

</div>
<div class="col-sm-2" > 


</div>

 </div>
<p style="color:#FFF; font-size:11px" class="pull-left"><?php  echo(date("Y"));?> All Rights Reserved to ATMJapan Company Limited </p>

<p style="color:#FFF; font-size:10px" class="pull-right">Designed and Developed by InnoSoft <a target="_blank" href="https://www.facebook.com/kkhurram.malik">Khurram</a> , <a target="_blank" href="https://www.facebook.com/usmansial93">Usman</a> and <a target="_blank" href="https://www.facebook.com/cool.buddy.982845">Ahmed </a> </p>
</nav>

</footer>
